# Import necessary libraries
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
import matplotlib.pyplot as plt

# Simulate traffic data
np.random.seed(42)
time = pd.date_range(start='2025-01-01', periods=500, freq='H')  # 500 hourly timestamps
traffic_flow = np.random.randint(50, 500, size=len(time))  # Random traffic flow values
temperature = np.random.uniform(15, 35, size=len(time))  # Random temperature values
humidity = np.random.uniform(30, 80, size=len(time))  # Random humidity values
is_rush_hour = [(1 if (6 <= t.hour <= 9 or 16 <= t.hour <= 19) else 0) for t in time]  # Rush hours flag

# Create a DataFrame
data = pd.DataFrame({
    'Timestamp': time,
    'Traffic_Flow': traffic_flow,
    'Temperature': temperature,
    'Humidity': humidity,
    'Is_Rush_Hour': is_rush_hour
})

# Preprocessing
X = data[['Temperature', 'Humidity', 'Is_Rush_Hour']]
y = data['Traffic_Flow']
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Build the neural network model
model = Sequential([
    Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
    Dropout(0.2),
    Dense(32, activation='relu'),
    Dense(1)  # Single output for regression
])
model.compile(optimizer='adam', loss='mean_squared_error', metrics=['mae'])
model.summary()

# Train the model
history = model.fit(X_train, y_train, validation_split=0.2, epochs=50, batch_size=32, verbose=1)

# Evaluate the model
test_loss, test_mae = model.evaluate(X_test, y_test, verbose=0)
print(f"Test Loss: {test_loss}, Test MAE: {test_mae}")

# Plot training history
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.title('Model Training and Validation Loss')
plt.show()

# Predictions vs Actuals
y_pred = model.predict(X_test)
plt.scatter(y_test, y_pred)
plt.xlabel('Actual Traffic Flow')
plt.ylabel('Predicted Traffic Flow')
plt.title('Actual vs Predicted Traffic Flow')
plt.show()
