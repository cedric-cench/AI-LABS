import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import DBSCAN
from PIL import Image

# Replace this with the path to your extracted dataset
dataset_directory = "lfw"

# Step 1: Load Dataset
def load_images(dataset_directory, image_size=(50, 50)):
    images = []
    labels = []
    label_names = []
    for label_id, folder in enumerate(os.listdir(dataset_directory)):
        folder_path = os.path.join(dataset_directory, folder)
        if os.path.isdir(folder_path):
            label_names.append(folder)
            for file in os.listdir(folder_path):
                file_path = os.path.join(folder_path, file)
                try:
                    img = Image.open(file_path).convert('L')  # Convert to grayscale
                    img = img.resize(image_size)  # Resize to fixed dimensions
                    images.append(np.array(img).flatten())  # Flatten into 1D array
                    labels.append(label_id)
                except Exception as e:
                    print(f"Error loading image {file_path}: {e}")
    return np.array(images), np.array(labels), label_names

print("Loading dataset...")
image_data, image_labels, label_names = load_images(dataset_directory)
print(f"Loaded {image_data.shape[0]} images from {len(label_names)} classes.")

# Step 2: Data Preprocessing
print("Scaling the data...")
scaler = StandardScaler()
image_data_scaled = scaler.fit_transform(image_data)

# Step 3: Dimensionality Reduction
print("Applying PCA...")
pca = PCA(n_components=50)
data_pca = pca.fit_transform(image_data_scaled)
print(f"Reduced data shape: {data_pca.shape}")

# Step 4: Clustering with DBSCAN
print("Clustering with DBSCAN...")
dbscan = DBSCAN(eps=2.5, min_samples=5, metric='euclidean')
cluster_labels = dbscan.fit_predict(data_pca)

# Analyze Clustering Results
n_clusters = len(set(cluster_labels)) - (1 if -1 in cluster_labels else 0)
n_noise = list(cluster_labels).count(-1)
print(f"Number of clusters found: {n_clusters}")
print(f"Number of noise points: {n_noise}")

# Step 5: Visualization
print("Visualizing results...")
plt.figure(figsize=(10, 6))
scatter = plt.scatter(data_pca[:, 0], data_pca[:, 1], c=cluster_labels, cmap='viridis', s=5)
plt.colorbar(scatter, label="Cluster Labels")
plt.title("DBSCAN Clustering Results")
plt.xlabel("PCA Component 1")
plt.ylabel("PCA Component 2")
plt.show()
